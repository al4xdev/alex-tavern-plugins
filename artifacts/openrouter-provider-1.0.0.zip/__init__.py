"""OpenRouter provider reference plugin."""
